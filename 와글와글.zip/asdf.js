exports.getPosts = (req, res) => {
    res.send('GET POSTS')
}

exports.newPosts = (req, res) => {
    res.send('NEW POSTS')
}
