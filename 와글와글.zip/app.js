var express = require('express');
const url = require('url');
var app = express()
const fs = require('fs');
server = require('http').Server(app);
var bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
  limit: '1gb',
  extended: false
}));

server.listen(80)
console.log("server start")

app.get('/main', (req, res) => { //메인 페이지
  res.sendfile(__dirname+"/main.html")
  });
app.get('/result/:keyword', (req, res) => {
    // var query = url.parse(req.url,true).query
    // console.log(query)
    res.sendfile(__dirname+"/result.html")

    // res.writeHead(200,{"Content-type":"text/html"})
    // res.end("VAL : "+req.params.keyword)
});
app.get('/res/:res', (req, res) => {
    res.sendfile(__dirname+"/res/"+req.params.res)
});
app.get('/res/white/:res', (req, res) => {
    res.sendfile(__dirname+"/res/white/"+req.params.res)
});
app.get('/res/red/:res', (req, res) => {
    res.sendfile(__dirname+"/res/red/"+req.params.res)
});
